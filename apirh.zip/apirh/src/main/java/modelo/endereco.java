package modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity

public class endereco {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String rua;
	private String provincia;
	private String bairro;
	private String pais;
	@ManyToOne
	private funcionario idfuncionario;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public funcionario getIdfuncionario() {
		return idfuncionario;
	}
	public void setIdfuncionario(funcionario idfuncionario) {
		this.idfuncionario = idfuncionario;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		endereco other = (endereco) obj;
		if (id != other.id)
			return false;
		return true;
	}

	
	
}
