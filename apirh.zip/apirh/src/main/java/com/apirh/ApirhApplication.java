package com.apirh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApirhApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApirhApplication.class, args);
	}

}
