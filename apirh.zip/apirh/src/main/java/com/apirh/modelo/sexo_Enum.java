package com.apirh.modelo;

public enum sexo_Enum {
MASCULINO("Masculino"),
FEMENINO("Femenino");
	
private String descricao;	

sexo_Enum(String descricao){
this.descricao=descricao;	
}

public String  getDescricao() {
	return descricao;
}
}
