package com.apirh.modelo;

import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class parametrizacaoponto {
@Id  @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private LocalTime horaentrada;
	private LocalTime horasaida;
	private int qtdhorasdias;
	@ManyToOne
	private ponto ponto;
	
	
	public parametrizacaoponto(LocalTime horaentrada,LocalTime horasaida,int qtdhorasdias,ponto ponto) {
		
		this.horaentrada=horaentrada;
		this.horasaida=horasaida;
		this.qtdhorasdias=qtdhorasdias;
		this.ponto=ponto;
	}
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public LocalTime getHoraentrada() {
		return horaentrada;
	}
	public void setHoraentrada(LocalTime horaentrada) {
		this.horaentrada = horaentrada;
	}
	public LocalTime getHorasaida() {
		return horasaida;
	}
	public void setHorasaida(LocalTime horasaida) {
		this.horasaida = horasaida;
	}
	public int getQtdhorasdias() {
		return qtdhorasdias;
	}
	public void setQtdhorasdias(int qtdhorasdias) {
		this.qtdhorasdias = qtdhorasdias;
	}
	public ponto getPonto() {
		return ponto;
	}
	public void setPonto(ponto ponto) {
		this.ponto = ponto;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((horaentrada == null) ? 0 : horaentrada.hashCode());
		result = prime * result + ((horasaida == null) ? 0 : horasaida.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((ponto == null) ? 0 : ponto.hashCode());
		result = prime * result + qtdhorasdias;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		parametrizacaoponto other = (parametrizacaoponto) obj;
		if (horaentrada == null) {
			if (other.horaentrada != null)
				return false;
		} else if (!horaentrada.equals(other.horaentrada))
			return false;
		if (horasaida == null) {
			if (other.horasaida != null)
				return false;
		} else if (!horasaida.equals(other.horasaida))
			return false;
		if (id != other.id)
			return false;
		if (ponto == null) {
			if (other.ponto != null)
				return false;
		} else if (!ponto.equals(other.ponto))
			return false;
		if (qtdhorasdias != other.qtdhorasdias)
			return false;
		return true;
	}
	
	
	
	
	
	
	
}
