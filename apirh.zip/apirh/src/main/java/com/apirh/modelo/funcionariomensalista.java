package com.apirh.modelo;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class funcionariomensalista {
@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
private long id;
private boolean isentodeponto;
private BigDecimal salariomes;
private BigDecimal bonospormes;
@OneToOne
private funcionariocontrato contrado;
@OneToOne
private funcionario idfuncionario;
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public boolean isIsentodeponto() {
	return isentodeponto;
}
public void setIsentodeponto(boolean isentodeponto) {
	this.isentodeponto = isentodeponto;
}
public BigDecimal getSalariomes() {
	return salariomes;
}
public void setSalariomes(BigDecimal salariomes) {
	this.salariomes = salariomes;
}
public BigDecimal getBonospormes() {
	return bonospormes;
}
public void setBonospormes(BigDecimal bonospormes) {
	this.bonospormes = bonospormes;
}
public funcionariocontrato getContrado() {
	return contrado;
}
public void setContrado(funcionariocontrato contrado) {
	this.contrado = contrado;
}
public funcionario getIdfuncionario() {
	return idfuncionario;
}
public void setIdfuncionario(funcionario idfuncionario) {
	this.idfuncionario = idfuncionario;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + (int) (id ^ (id >>> 32));
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	funcionariomensalista other = (funcionariomensalista) obj;
	if (id != other.id)
		return false;
	return true;
}


	
}
