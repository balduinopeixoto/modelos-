package com.apirh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApirhApplicationTests {

	@Test
	void contextLoads() {
	}

}
